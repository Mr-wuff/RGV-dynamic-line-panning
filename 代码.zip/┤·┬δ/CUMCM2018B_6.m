        if probability() == 1
            fault = unidrnd(target(3,1));  %在工作时间内随机产生一个时间点
            cnc_fixTime = 600 + unidrnd(600);  %维修时间在10~20分钟之间
            code = code - 1;
            target(code,4) = inf;  %未正常下料标记
            target(code,6) = Time + fault;  %故障开始时间
            target(code,7) = Time + fault + cnc_fixTime;  %故障结束的时间
            target(code,5) = inf;  %发生故障的标志
            code = code + 1;
        end
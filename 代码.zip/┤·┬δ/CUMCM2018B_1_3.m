clear;clc;
cnc_place=xlsread('cnc.xlsx','sheet3','B2:I2');%%cnc的位置
cnc_status=xlsread('cnc.xlsx','sheet3','B3:I3');%%cnc的状态
cnc_workingTime=xlsread('cnc.xlsx','sheet3','B4');%%cnc的工作时间
cnc_prepareTime=xlsread('cnc.xlsx','sheet3','B5:I5');%%cnc的上下件时间
rgv_place=xlsread('rgv.xlsx','sheet3','B2');%%rgv的位置
rgv_status=xlsread('rgv.xlsx','sheet3','B3');%%rgv的状态
rgv_moveOne=xlsread('rgv.xlsx','sheet3','B4');%%rgv移动一格的时间
rgv_moveTwo=xlsread('rgv.xlsx','sheet3','B5');%%rgv移动两格的时间
rgv_moveThree=xlsread('rgv.xlsx','sheet3','B6');%%rgv移动三格的时间
rgv_workingTime=xlsread('rgv.xlsx','sheet3','B7');%%rgv的洗件时间
start=xlsread('cnc.xlsx','sheet3','B8:I8');
target=zeros(13,3);
targetMes(2,100)=zeros;
Num=1;
code=1;%%加工物料编号
over=-1;
Time=0;
test=0;
while Time<=28800
    for codeNum=1:1:8
        if start(codeNum)>over
            target(code,2)=start(codeNum);
            target(code,1)=codeNum;
            over=start(codeNum);
            code=code+1;
        end
        targetMes(1,Num)=codeNum;
        targetMes(2,Num)=start(codeNum);
        Num=Num+1;
    end
    
    for number=1:1:8
        if Time-start(number)>=cnc_workingTime
            cnc_status(number)=0;
        end
    end
    %%都在工作
    if (cnc_status(1)==1&&cnc_status(2)==1&&cnc_status(3)==1&&cnc_status(4)==1&&cnc_status(5)==1&&cnc_status(6)==1&&cnc_status(7)==1&&cnc_status(8)==1)
        Time=Time+1;
        continue;
    end
    %%第一种情况：加工cnc1或cnc2
    if (cnc_status(1)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置1
            rgv_place=1;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置1
            Time=Time+rgv_moveOne;
            rgv_place=1;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置1
            Time=Time+rgv_moveTwo;
            rgv_place=1;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置1
            Time=Time+rgv_moveThree;
            rgv_place=1;
        end
        if cnc_status(1)==0
            start(1)=Time;
            Time=Time+cnc_prepareTime(1);
            cnc_status(1)=1;            
        end
        continue;
    end
    if (cnc_status(2)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置1
            rgv_place=1;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置1
            Time=Time+rgv_moveOne;
            rgv_place=1;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置1
            Time=Time+rgv_moveTwo;
            rgv_place=1;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置1
            Time=Time+rgv_moveThree;
            rgv_place=1;
        end
        if cnc_status(2)==0
            start(2)=Time;
            Time=Time+cnc_prepareTime(2);
            cnc_status(2)=1;           
        end
        continue;
    end
    %%第二种情况：加工cnc3或cnc4
    if (cnc_status(3)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置2
            rgv_place=2;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置2
            Time=Time+rgv_moveTwo;
            rgv_place=2;
        end
        if cnc_status(3)==0
            start(3)=Time;
            Time=Time+cnc_prepareTime(3);
            cnc_status(3)=1;
        end
        continue;
    end 
    if (cnc_status(4)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置2
            rgv_place=2;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置2
            Time=Time+rgv_moveTwo;
            rgv_place=2;
        end
        if cnc_status(4)==0
            start(4)=Time;
            Time=Time+cnc_prepareTime(4);
            cnc_status(4)=1;
        end
        continue;
    end 
    %%第三种情况：加工cnc5或cnc6
    if (cnc_status(5)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置3
            Time=Time+rgv_moveTwo;
            rgv_place=3;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置3
            rgv_place=3;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if cnc_status(5)==0
            start(5)=Time;
            Time=Time+cnc_prepareTime(5);
            cnc_status(5)=1;            
        end
        continue;
    end
    if (cnc_status(6)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置3
            Time=Time+rgv_moveTwo;
            rgv_place=3;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置3
            rgv_place=3;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if cnc_status(6)==0
            start(6)=Time;
            Time=Time+cnc_prepareTime(6);
            cnc_status(6)=1;            
        end
        continue;
    end
    %%第四种情况：加工cnc7或cnc8
    if (cnc_status(7)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置4
            Time=Time+rgv_moveOne;
            rgv_place=4;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置4
            Time=Time+rgv_moveTwo;
            rgv_place=4;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置4
            Time=Time+rgv_moveThree;
            rgv_place=4;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置4
            rgv_place=4;
        end
        if cnc_status(7)==0
            start(7)=Time;
            Time=Time+cnc_prepareTime(7);
            cnc_status(7)=1;           
        end
        continue;
    end   
    if (cnc_status(8)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置4
            Time=Time+rgv_moveOne;
            rgv_place=4;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置4
            Time=Time+rgv_moveTwo;
            rgv_place=4;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置4
            Time=Time+rgv_moveThree;
            rgv_place=4;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置4
            rgv_place=4;
        end
        if cnc_status(8)==0
            start(8)=Time;
            Time=Time+cnc_prepareTime(8);
            cnc_status(8)=1;           
        end
        continue;
    end
end
for i=1:1:13
    for j=1:1:201880
        if targetMes(1,j)==target(i,1)&&targetMes(2,j)>target(i,2)
            target(i,3)=targetMes(2,j);
            break;
        end
    end
end
xlswrite('Case_1_result.xls',target,'第三组','B2:D14');
    


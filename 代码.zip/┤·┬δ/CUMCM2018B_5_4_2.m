clear all;clc;
 
%全局搜索判优使用
%  ls = [1,2,3,4,5,6,7,8];
%  tmp = 0;
%  f = perms(ls);
%      for ii = 1:length(f)  
%          ls1 = f(ii,1:4);
%          ls2 = f(ii,5:8);
 
%做第一、二道工序的cnc：
ls1=[1,4,6,8];                                                  
ls2=[2,3,5,7];  
work1=400;
work2=378;
 
%%数据导入
 
%1.cnc: 
% 第一行：cnc位置常量
% 第二行：cnc工作变量，空闲为0，忙碌为1
% 第三行：cnc工作时间
% 第四行：cnc上下料时间
% 第五行：cnc预计完成时间
% 第六行：正在加工的物料编号
% 第七行：cnc是否初始判断，0为初始，1位正常
cnc = load ('2_cnc_2.txt');
for i=ls1
    cnc(3,i)=work1;
end
for i=ls2
    cnc(3,i)=work2;
end
%2.rgv：
% 第一行：rgv初始位置变量，初始为1
% 第二行：rgv工作变量，进行上下料或清洗作业，空闲为0，忙碌为1
% 第三行：rgv一次清洗作业时间
% 第四行：rgv预计完成时间
% 第五行：正在操作的物料编号
rgv = load ('2_rgv_2.txt');
 
%3.speedRgv：
%移动1~3个单位所需时间
speedRgv = load('2_speedRgv_2.txt');
 
case_1_result = (1:800)';
t = 0;
r = 1;  %计数
flag = 0;  %rgv上有半成品物料为1，没有为0；
while t <= 28800  %以秒为计数单位
    
    %1.在rgv和cnc均空闲状态下，找到距离最近的cnc,并让rgv移动过去
    % 第一道加工：
    dist = 4; signal = 0;
    for i=ls1
        if cnc(2,i) == 0 && flag == 0  %如果cnc空闲，rgv上没有半成品物料
            if abs(cnc(1,i)-rgv(1))<dist  %找到距离rgv最近的cnc并返回cnc编号
                dist = abs(cnc(1,i)-rgv(1));
                cncNum1 = i;
                value = cnc(1,i);
                step = abs(cnc(1,i)-rgv(1));
            end
        end
    end
    if step ~= 0 && cnc(2,cncNum1) == 0 && flag == 0 %rgv移动到最近的cnc处..若rgv在等待，rgv也将移动到最近的cnc处
        t = t + speedRgv(step);
        rgv(1) = value;
        signal = 1;
    end
    
  
    %2.rgv对第一道工序进行上下料操作
    if  cnc(2,cncNum1)==0 && flag == 0  %该cnc空闲，且rgv上没有半成品物料
        cnc(2,cncNum1) = 1;   
        %记录加工cnc的编号
        case_1_result(r,2) = cncNum1;
        case_1_result(r,3) = t;
        t = t + cnc(4,cncNum1);  %上下料
        signal = 1;
        cnc(7,cncNum1) = cnc(7,cncNum1) + 1;  %初始判定条件
        if cnc(7,cncNum1) > 1 %若该cnc不是初始化状态
            rgv(5) = cnc(6,cncNum1);  %记录rgv操作的前一个是哪一个物料
            flag = 1; % 表示rgv拿了一个物料
        end
        cnc(5,cncNum1) = t + cnc(3,cncNum1);  %cnc预计完成时间=上下料+工作时间
        cnc(6,cncNum1) = r;  %被加工物料的编号
        r = r + 1;
    end
    
    if probability() == 1
            fault = unidrnd(cnc(3,1));  %在工作时间内随机产生一个时间点
            tBroken = 600 + unidrnd(600);  %维修时间在10~20分钟之间
            disp('发生故障！');
            r = r - 1;
            case_1_result(r,4) = inf;  %未正常下料标记
            case_1_result(r,9) = t + fault;  %故障开始时间
            case_1_result(r,10) = t + fault + tBroken;  %故障结束的时间
            case_1_result(r,8) = inf;  %发生故障的标志
            r = r + 1;
            cnc(5,cncNum1) = t + fault + tBroken;  %cnc故障：cnc预计人工修理完成时间
        else
            cnc(5,cncNum1) = t + cnc(3,cncNum1);  %正常情况：cnc预计完成时间=上下料+工作时间
            cnc(6,cncNum1) = cnc(6,cncNum1) + 1;
    end
    
 
    
    %3.rgv在第一道工序的cnc处取物料后，寻找最近的第二道工序cnc
    dist = 4;
    if cnc(7,cncNum1) > 1 && flag == 1  %如果第一道工序的cnc不是初始状态，且rgv携带了半成品物料
        for i=ls2
            if cnc(2,i) == 0  %如果第二道工序cnc空闲
                if abs(cnc(1,i)-rgv(1))<dist  %找到距离最近的cnc并返回cnc编号
                    dist = abs(cnc(1,i)-rgv(1));
                    cncNum2 = i;
                    value = cnc(1,i);
                    step2 = abs(cnc(1,i)-rgv(1));
                end
            end
        end
        if step2 ~= 0 && cnc(2,cncNum2)==0 %rgv移动到最近的第二道工序cnc处
            t = t + speedRgv(step2);
            rgv(1) = value;
            signal = 1;
        end
    end
    
    
    %4.rgv对第二道工序进行上下料操作
    if  cnc(7,cncNum1) > 1 && cnc(2,cncNum2)==0 && flag == 1  %第二道工序cnc空闲，第一道工序cnc不为初始状态，rgv上有半成品物料
        cnc(2,cncNum2) = 1; 
        flag = 0;
        %记录加工cnc的编号
        case_1_result(rgv(5),5) = cncNum2;
        case_1_result(rgv(5),6) = t;
        cnc(6,cncNum2) = rgv(5); %正在被加工物料的编号
        t = t + cnc(4,cncNum2);  %上下料
        signal = 1;
        cnc(5,cncNum2) = t + cnc(3,cncNum2);  %第二道工序cnc预计完成时间=上下料+工作时间
        if cnc(7,cncNum2) > 0 
            t = t + rgv(3);  %时间=上下料+清洗时间
        end
        cnc(7,cncNum2) = cnc(7,cncNum2) + 1;
    
    
    if probability() == 1
            fault = unidrnd(cnc(3,1));  %在工作时间内随机产生一个时间点
            tBroken = 600 + unidrnd(600);  %维修时间在10~20分钟之间
            disp('发生故障！');
            r = r - 1;
            case_1_result(r,7) = inf;  %未正常下料标记
            case_1_result(r,12) = t + fault;  %故障开始时间
            case_1_result(r,13) = t + fault + tBroken;  %故障结束的时间
            case_1_result(r,11) = inf;  %发生故障的标志
            r = r + 1;
            cnc(5,cncNum2) = t + fault + tBroken;  %cnc故障：cnc预计人工修理完成时间
        else
            cnc(5,cncNum2) = t + cnc(3,cncNum2);  %正常情况：cnc预计完成时间=上下料+工作时间
            cnc(6,cncNum2) = cnc(6,cncNum2) + 1;
    end
    end
    
    %5.所有的cnc均忙碌，rgv在等待
    for i = 1:8
        if t >= cnc(5,i) && cnc(5,i) ~= 0
            cnc(2,i) = 0;
        end
    end
    
    if signal == 0
        t = t +1; %若rgv在原地等待
     else
         continue;
    end
 
end
 
 
%计算下料开始时间，即改cnc的下一次上料时间
for i = 1:800
    for j =i+1:800
        if case_1_result(i,2)==case_1_result(j,2)
            case_1_result(i,4)=case_1_result(j,3);
            break;
        end
    end
    for k =i+1:800
        if case_1_result(i,5)==case_1_result(k,5)
            case_1_result(i,7)=case_1_result(k,6);
            break;
        end
    end
end
 
%全局搜索判优使用
%   for i = 1:800
%       if case_1_result(i,7)==0
%           set = i;
%           break;
%       end
%   end   
%   if tmp<set   
%       tmp = set;
%       xx = ii;  %特征
%   end
% end
% disp('ls1:');
% disp(f(xx,1:4));
% disp('ls2:');
% disp(f(xx,5:8));
 
if probability() == 1
            fault = unidrnd(cnc(3,1));  %在工作时间内随机产生一个时间点
            tBroken = 600 + unidrnd(600);  %维修时间在10~20分钟之间
            disp('发生故障！');
            r = r - 1;
            case_1_result(r,4) = inf;  %未正常下料标记
            case_1_result(r,6) = t + fault;  %故障开始时间
            case_1_result(r,7) = t + fault + tBroken;  %故障结束的时间
            case_1_result(r,5) = inf;  %发生故障的标志
            r = r + 1;
            cnc(5,cncNum) = t + fault + tBroken;  %cnc故障：cnc预计人工修理完成时间
        else
            cnc(5,cncNum) = t + cnc(3,cncNum);  %正常情况：cnc预计完成时间=上下料+工作时间
            cnc(6,cncNum) = cnc(6,cncNum) + 1;
end

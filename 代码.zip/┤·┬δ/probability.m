%百分之一概率生成函数
function [key] = probability()
R=rand(1,1000);
if(R(100)<=0.01)
    key = 1;
else
    key = 0;
end
end
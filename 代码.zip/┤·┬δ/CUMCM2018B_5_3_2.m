clear all;clc;
%cnc: 
% 第一行：cnc位置常量
% 第二行：cnc工作变量，空闲为0，忙碌为1
% 第三行：cnc工作时间，为常量560
% 第四行：cnc上下料时间
% 第五行：cnc预计完成时间
% 第六行：cnc加工物料数
cnc = load ('1_cnc_2.txt');
cnc(6,:)=-1;
%rgv：
% 第一行：rgv初始位置变量，初始为1
% 第二行：rgv工作变量，进行上下料或清洗作业，空闲为0，忙碌为1
% 第三行：rgv一次清洗作业时间
% 第四行：rgv预计完成时间
rgv = load ('1_rgv_2.txt');
 
%speedRgv：
%移动1~3个单位所需时间
speedRgv = load('1_speedRgv_2.txt');
 
case_1_result = (1:800)';
t = 0;
r = 1;  %仅计数用
 
while t <= 28800  %以秒为计数单位
    
    %1.在rgv和cnc均空闲状态下，找到距离最近的cnc编号
    dist = 4; 
    signal = 0;
        for i=1:8
            if cnc(2,i) == 0  %如果cnc空闲
                if abs(cnc(1,i)-rgv(1))<dist  %找到距离最近的cnc并返回cnc编号
                    dist = abs(cnc(1,i)-rgv(1));
                    cncNum = i;
                    value = cnc(1,i);  %记录cnc位置以传递给rgv
                    step = abs(cnc(1,i)-rgv(1));  %rgv走的步数的绝对值
                end
            end
        end
        if step ~= 0 && cnc(2,cncNum) == 0  %rgv移动到最近的cnc处
            t = t + speedRgv(step);
            rgv(1) = value;
            signal = 1;
        end
  
    %2.上下料和清洗操作
    if  cnc(2,cncNum) == 0
        cnc(2,cncNum) = 1; 
        rgv(2) = 1;  
        %记录加工cnc的编号
        case_1_result(r,2) = cncNum;
        case_1_result(r,3) = t;
        t = t + cnc(4,cncNum);  %上下料
        cnc(6,cncNum) = cnc(6,cncNum) + 1;
        signal = 1;
        cnc(5,cncNum) = t + cnc(3,cncNum);  %cnc预计完成时间=上下料+工作时间
        if cnc(5,cncNum) ~= 0
            t = t + rgv(3);  %清洗作业完成时间=上下料+清洗时间
        end
        r = r + 1; 
    end
    
    if probability() == 1
            fault = unidrnd(cnc(3,1));  %在工作时间内随机产生一个时间点
            tBroken = 600 + unidrnd(600);  %维修时间在10~20分钟之间
            disp('发生故障！');
            r = r - 1;
            case_1_result(r,4) = inf;  %未正常下料标记
            case_1_result(r,6) = t + fault;  %故障开始时间
            case_1_result(r,7) = t + fault + tBroken;  %故障结束的时间
            case_1_result(r,5) = inf;  %发生故障的标志
            r = r + 1;
            cnc(5,cncNum) = t + fault + tBroken;  %cnc故障：cnc预计人工修理完成时间
    else
            cnc(5,cncNum) = t + cnc(3,cncNum);  %正常情况：cnc预计完成时间=上下料+工作时间
            cnc(6,cncNum) = cnc(6,cncNum) + 1;
    end
    
    %3.更改cnc状态为空闲
    for i = 1:8
        if t >= cnc(5,i) && cnc(5,i) ~= 0
            cnc(2,i) = 0;
        end
    end
 
    if signal == 0
        t = t +1;
    %else
        %continue;
    end
    
end
 
 
%计算下料开始时间，即改cnc的下一次上料时间
for i = 1:800
    for j =i+1:800
        if case_1_result(i,2)==case_1_result(j,2)
            case_1_result(i,4)=case_1_result(j,3);
            break;
        end
    end
end
    
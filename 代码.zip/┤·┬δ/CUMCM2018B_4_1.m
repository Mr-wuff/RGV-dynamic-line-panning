clear;clc;
cnc_place=xlsread('cnc.xlsx','sheet1','B2:I2');%%cnc的位置
cnc_status=xlsread('cnc.xlsx','sheet1','B3:I3');%%cnc的状态
cnc_workingTimeFirst=xlsread('cnc.xlsx','sheet1','B9');%%cnc的第一道工作时间
cnc_workingTimeSecond=xlsread('cnc.xlsx','sheet1','B10');%%cnc的第二道工作时间
cnc_prepareTime=xlsread('cnc.xlsx','sheet1','B5:I5');%%cnc的上下件时间
rgv_place=xlsread('rgv.xlsx','sheet1','B2');%%rgv的位置
rgv_status=xlsread('rgv.xlsx','sheet1','B3');%%rgv的状态
rgv_moveOne=xlsread('rgv.xlsx','sheet1','B4');%%rgv移动一格的时间
rgv_moveTwo=xlsread('rgv.xlsx','sheet1','B5');%%rgv移动两格的时间
rgv_moveThree=xlsread('rgv.xlsx','sheet1','B6');%%rgv移动三格的时间
rgv_workingTime=xlsread('rgv.xlsx','sheet1','B7');%%rgv的洗件时间
start1=xlsread('cnc.xlsx','sheet1','B8:I8');
start2=start1;
target=zeros(1000,10);
targetMes(2,100)=zeros;
Num=1;
code=1;%%加工物料编号
over1=-1;over2=-1;
Time=0;
test=0;
flag=zeros(1,4);
while Time<=28800
    for codeNum=1:1:8
            if probability() == 1
                fault = unidrnd(target(3,1));  %在工作时间内随机产生一个时间点
                cnc_fixTime = 600 + unidrnd(600);  %维修时间在10~20分钟之间
                code = code - 1;
                target(code,7) = inf;  %未正常下料标记
                target(code,9) = Time + fault;  %故障开始时间
                target(code,10) = Time + fault + cnc_fixTime;  %故障结束的时间
                target(code,8) = inf;  %发生故障的标志
                code = code + 1;
            end
        if start1(codeNum)>over1
            target(code,2)=start1(codeNum);
            target(code,1)=codeNum;
            over1=start1(codeNum);
            code=code+1;
        end
        targetMes(1,Num)=codeNum;
        targetMes(2,Num)=start1(codeNum);
        targetMes(3,Num)=codeNum;
        targetMes(4,Num)=start2(codeNum);
        Num=Num+1;
    end
    
    for number=1:1:8
        if number/2~=0&&Time-start1(number)>=cnc_workingTimeFirst
            cnc_status(number)=0;
        end
        if number/2==0&&Time-start2(number)>=cnc_workingTimeSecond
            cnc_status(1,number)=0;
        end
    end
    %%都在工作
    if ((cnc_status(1)==1||cnc_status(2)==1)&&(cnc_status(3)==1||cnc_status(4)==1)&&(cnc_status(5)==1||cnc_status(6)==1)&&(cnc_status(7)==1||cnc_status(8)==1))
        Time=Time+1;
        continue;
    end
    %%第一种情况：加工cnc1第一道或cnc2第二道
    
    if (cnc_status(1)==0&&cnc_status(2)==0&&flag(1,1)==1)
        if 0==abs(rgv_place-1)%%从位置1移动到位置1
            rgv_place=1;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置1
            Time=Time+rgv_moveOne;
            rgv_place=1;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置1
            Time=Time+rgv_moveTwo;
            rgv_place=1;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置1
            Time=Time+rgv_moveThree;
            rgv_place=1;
        end
        if cnc_status(2)==0
            start2(2)=Time;
            Time=Time+cnc_prepareTime(2);
            cnc_status(2)=1;
            flag(1,1)=0;
        end
        continue;
    end
    if (cnc_status(1)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置1
            rgv_place=1;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置1
            Time=Time+rgv_moveOne;
            rgv_place=1;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置1
            Time=Time+rgv_moveTwo;
            rgv_place=1;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置1
            Time=Time+rgv_moveThree;
            rgv_place=1;
        end
        if cnc_status(1)==0
            start1(1)=Time;
            Time=Time+cnc_prepareTime(1);
            cnc_status(1)=1; 
            flag(1,1)=1;
        end
        continue;
    end
    %%第二种情况：加工cnc3第一道或cnc4第二道
     
    if (cnc_status(3)==0&&cnc_status(4)==0&&flag(1,2)==1)
        if 0==abs(rgv_place-1)%%从位置1移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置2
            rgv_place=2;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置2
            Time=Time+rgv_moveTwo;
            rgv_place=2;
        end
        if cnc_status(4)==0
            start2(4)=Time;
            Time=Time+cnc_prepareTime(4);
            cnc_status(4)=1;
            flag(1,2)=0;
        end
        continue;
    end 
    if (cnc_status(3)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置2
            rgv_place=2;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置2
            Time=Time+rgv_moveOne;
            rgv_place=2;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置2
            Time=Time+rgv_moveTwo;
            rgv_place=2;
        end
        if cnc_status(3)==0
            start1(3)=Time;
            Time=Time+cnc_prepareTime(3);
            cnc_status(3)=1;
            flag(1,2)=1;
        end
        continue;
    end
    %%第三种情况：加工cnc5第一道或cnc6第二道
    
    if (cnc_status(5)==0&&cnc_status(6)==0&&flag(1,3)==1)
        if 0==abs(rgv_place-1)%%从位置1移动到位置3
            Time=Time+rgv_moveTwo;
            rgv_place=3;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置3
            rgv_place=3;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if cnc_status(6)==0
            start2(6)=Time;
            Time=Time+cnc_prepareTime(6);
            cnc_status(6)=1;
            flag(1,3)=0;
        end
        continue;
    end
    if (cnc_status(5)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置3
            Time=Time+rgv_moveTwo;
            rgv_place=3;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置3
            rgv_place=3;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置3
            Time=Time+rgv_moveOne;
            rgv_place=3;
        end
        if cnc_status(5)==0
            start1(5)=Time;
            Time=Time+cnc_prepareTime(5);
            cnc_status(5)=1;
            flag(1,3)=1;
        end
        continue;
    end
    %%第四种情况：加工cnc7第一道或cnc8第二道
       
    if (cnc_status(7)==0&&cnc_status(8)==0&&flag(1,4)==1)
        if 0==abs(rgv_place-1)%%从位置1移动到位置4p
            Time=Time+rgv_moveOne;
            rgv_place=4;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置4
            Time=Time+rgv_moveTwo;
            rgv_place=4;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置4
            Time=Time+rgv_moveThree;
            rgv_place=4;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置4
            rgv_place=4;
        end
        if cnc_status(8)==0
            start2(8)=Time;
            Time=Time+cnc_prepareTime(8);
            cnc_status(8)=1;
            flag(1,4)=0;
        end
        continue;
    end
    if (cnc_status(7)==0)
        if 0==abs(rgv_place-1)%%从位置1移动到位置4
            Time=Time+rgv_moveOne;
            rgv_place=4;
        end
        if 0==abs(rgv_place-2)%%从位置2移动到位置4
            Time=Time+rgv_moveTwo;
            rgv_place=4;
        end
        if 0==abs(rgv_place-3)%%从位置3移动到位置4
            Time=Time+rgv_moveThree;
            rgv_place=4;
        end
        if 0==abs(rgv_place-4)%%从位置4移动到位置4
            rgv_place=4;
        end
        if cnc_status(7)==0
            start1(7)=Time;
            Time=Time+cnc_prepareTime(7);
            cnc_status(7)=1;
            flag(1,4)=1;
        end
        continue;
    end
end
for code=1:1:1000
    target(code,4)=target(code,1)+1;
end
for i=1:1:1000
    for j=1:1:56920
        if targetMes(1,j)==target(i,1)&&targetMes(2,j)>target(i,2)
            target(i,3)=targetMes(2,j);
            break;
        end
    end
end
for i=1:1:1000
    for j=1:1:56920
        if targetMes(3,j)==target(i,4)&&targetMes(4,j)>target(i,3)
            target(i,5)=targetMes(4,j);
            break;
        end
    end
end
for i=1:1:1000
    for j=1:1:56920
        if targetMes(3,j)==target(i,4)&&targetMes(4,j)>target(i,5)
            target(i,6)=targetMes(4,j);
            break;
        end
    end
end
    
xlswrite('Case_3_result_2.xls',target,'第一组','B2:K1001');
    

